package fr.antoinebaudot.lab1mad;

/**
 * Created by s254741 on 06/04/2018.
 */

public class User {
    private String nom ;
    private Long age ;

    public User(){};

    public String getNom() {
        return nom;
    }

    public Long getAge() {
        return age;
    }
}
